

import Foundation

// Declare your constants here
struct ProductConstant {
    static let productURLString = "https://dl.dropboxusercontent.com/s/2iodh4vg0eortkl/facts.json"
}
